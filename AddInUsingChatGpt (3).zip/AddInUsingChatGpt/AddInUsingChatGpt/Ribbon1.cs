﻿using Microsoft.Office.Tools.Ribbon;
using OpenAI_API;
using OpenAI_API.Completions;
using System;
using System.Threading.Tasks;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Windows.Forms;

namespace AddInUsingChatGpt
{
    public partial class Ribbon1
    {
        private OpenAIAPI api;

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            // Initialize OpenAI API with your API key
            string apiKey = "openai_api_key";
            api = new OpenAIAPI(apiKey);
        }

        private async void button1_Click(object sender, RibbonControlEventArgs e)
        {
            await GenerateEmail("Generate a professional email response based on the following content.");
        }

        private async void button3_Click(object sender, RibbonControlEventArgs e)
        {
            await GenerateEmail("Generate a casual email response based on the following content.");
        }

        private async void button2_Click(object sender, RibbonControlEventArgs e)
        {
            await GenerateEmail("Generate a correct email response based on the following content.");
        }

        private async void button4_Click(object sender, RibbonControlEventArgs e)
        {
            string language = PromptForLanguage();
            await GenerateEmail($"Generate an email in {language} about the importance of submitting files on time.");
        }

        private string PromptForLanguage()
        {
            string language = "";
            language = Microsoft.VisualBasic.Interaction.InputBox("Please enter the language for conversion:", language);
            return language;
        }

        private async Task GenerateEmail(string promptTemplate)
        {
            Outlook.Application application = Globals.ThisAddIn.Application;
            Outlook.Inspector inspector = application.ActiveInspector();
            Outlook.MailItem mailItem = inspector.CurrentItem as Outlook.MailItem;

            if (mailItem != null)
            {
                string currentBody = mailItem.HTMLBody;
                string currentSubject = mailItem.Subject;

                string prompt = $"{promptTemplate}\n\nSubject: {currentSubject}\n\nBody: {currentBody}";
                string emailContent = await GenerateEmailAsync(prompt);

                if (!string.IsNullOrEmpty(emailContent))
                {
                    mailItem.HTMLBody = emailContent;
                    // Optionally set the subject if you want to keep it dynamic
                    mailItem.Subject = currentSubject;
                }
            }
        }

        private async Task<string> GenerateEmailAsync(string prompt)
        {
            var completionRequest = new CompletionRequest
            {
                Prompt = prompt,
                MaxTokens = 500 // Adjust the number of tokens as needed
            };

            var completionResult = await api.Completions.CreateCompletionAsync(completionRequest);

            if (completionResult != null && completionResult.Completions.Count > 0)
            {
                return completionResult.Completions[0].Text;
            }

            return string.Empty;
        }

        private void button5_Click(object sender, RibbonControlEventArgs e)
        {

        }
    }
}
